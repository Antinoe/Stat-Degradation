using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;


namespace StatDegradation
{
	public class StatDegradation : Mod
	{
		public override void AddRecipes()
		{
			CreateRecipe(ItemID.LifeCrystal,1)
            .AddIngredient(ItemID.Ruby, 1)
            .AddIngredient(3, 10) //Stone
            .AddTile(TileID.WorkBenches)
            .Register();
			
			CreateRecipe(ItemID.ManaCrystal,1)
            .AddIngredient(ItemID.Sapphire, 1)
            .AddIngredient(3, 10) //Stone
            .AddTile(TileID.WorkBenches)
            .Register();
			
			CreateRecipe(ItemID.LifeFruit,1)
            .AddIngredient(ItemID.HallowedBar, 1)
            .AddIngredient(ItemID.Vine, 10)
            .AddTile(TileID.WorkBenches)
            .Register();
		}
    }
}
