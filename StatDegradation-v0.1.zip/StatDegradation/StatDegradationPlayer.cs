﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace StatDegradation
{
    public class StatDegradationPlayer : ModPlayer
    {
		//public bool isDead; //Unused.
		//public int deathLossCooldown = 0; //Unused.
		public int lifeLossCooldown = 0;
		public int manaLossCooldown = 0;
		public static StatDegradationPlayer ModPlayer(Player Player)
		{
			return Player.GetModPlayer<StatDegradationPlayer>();
		}
		public override void PostUpdate()
		{
			//Stat Loss over time.
			if(lifeLossCooldown > 0)
			{
				lifeLossCooldown--;
			}
			if(manaLossCooldown > 0)
			{
				manaLossCooldown--;
			}
			if(lifeLossCooldown == 0 && Player.statLifeMax > 20)
			{
				Player.statLifeMax -=1;
				lifeLossCooldown = 2400;
			}
			if(manaLossCooldown == 0 && Player.statManaMax > 20)
			{
				Player.statManaMax -=1;
				manaLossCooldown = 2400;
			}
		}
		/*public override void PreUpdate()
		{
			//Old method. I decided not to make this mod function through death or injury.
			if (Player.dead)
			{
				isDead = true;
			}
			if(isDead)
			{
				deathLossCooldown = 100;
			}
			if(deathLossCooldown > 0)
			{
				deathLossCooldown--;
			}
			if(deathLossCooldown >= 100)
			{
				Player.statLifeMax -= 20;
				Player.statManaMax -= 20;
			}
		}*/
    }
}